class SetReels {
  final List<Map<String, dynamic>> reels;
  SetReels(this.reels);
}

class ClearReels {}

