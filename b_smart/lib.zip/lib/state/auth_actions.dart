class SetAuthenticated {
  final String userId;
  SetAuthenticated(this.userId);
}

class ClearAuthentication {}

