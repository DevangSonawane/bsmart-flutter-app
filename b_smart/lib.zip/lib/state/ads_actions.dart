class SetAds {
  final List<Map<String, dynamic>> ads;
  SetAds(this.ads);
}

class ClearAds {}

