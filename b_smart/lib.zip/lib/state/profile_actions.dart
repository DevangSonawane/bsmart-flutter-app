class SetProfile {
  final Map<String, dynamic> profile;
  SetProfile(this.profile);
}

class ClearProfile {}

